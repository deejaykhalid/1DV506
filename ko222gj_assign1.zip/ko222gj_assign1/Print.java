package ko222gj_assign1;

public class Print {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
       
         System.out.println("Knowledge Is Power!\n");

     	System.out.println("Knowledge");
     	System.out.println("  Is");
     	System.out.println(" Power!\n");

     	System.out.println("=============");
     	System.out.println("| Knowledge |");
     	System.out.println("|   is      |");
     	System.out.println("|  power    |");
     	System.out.println("=============");

	}

}
